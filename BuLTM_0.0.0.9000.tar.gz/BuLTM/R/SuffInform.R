#' Functions for sufficient informativeness criterion
#' @import rstan
#' @param object The BuLTM object
#' @export

SuffitInf <- function(object){
  if(!inherits(object, "BuLTM"))
    stop("unavailable object")

  probseries <- object$probseries
  knots <- object$knots
  t <- object$t
  eta <- object$eta
  zeta <- object$zeta
  v <- object$v

  q0 <- min(probseries[which(probseries > 1- exp(-1))])
  t0 <- max(knots[names(knots) == paste0(as.character(q0), '%')])
  Yspline <- object$Yspline

  loc <- which.min(abs(t - t0))

  length <- z$length


  c11 <- A1_chain$alpha[1:length, ] %*% Yspline[, loc]
  c12 <- A1_chain$alpha[(length+1):(2*length), ]  %*% Yspline[, loc]
  c13 <- A1_chain$alpha[(2*length+1):(3*length), ]  %*% Yspline[, loc]
  c14 <- A1_chain$alpha[(3*length+1):(4*length), ]  %*% Yspline[, loc]

  knot.loc <- which(knots == t0)

  withinchain <- mean(c(var(c11), var(c12), var(c13), var(c14)))

  InvInformation <- 1/(K*zeta + eta/(knot.loc+4))^2 +
    1/(K*zeta + eta/(knot.loc+4))

  return(list(
    withinchain = withinchain,
    InvInformation =  InvInformation,
    knot.loc <- knot.loc
  ))
}


